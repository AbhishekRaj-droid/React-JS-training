import React from 'react';

function Body() {
    return(
        <div>
            <h2>This is Body Area</h2>
        </div>
    );
}

export default Body;